package za.ac.cput.runmyjtable;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author PHIHLE
 */
public class MyJTable extends JFrame implements ActionListener {

    private JComboBox service = new JComboBox(new String[]{"Services", "Plumber", "Gardner", "Baby Sitting", "Painting"});
    private JPanel pnlTop = new JPanel();
    private JPanel pnlCenter = new JPanel();
    private JPanel pnlBtm = new JPanel();
    private JLabel lblService = new JLabel("Service Rendered");
    private JLabel lblname = new JLabel(" Name :");
    private JTextField txtName = new JTextField();
    private JLabel lblsurname = new JLabel(" Surname ");
    private JTextField txtSurname = new JTextField();
    private JLabel lblGender = new JLabel("Gender");
    private JRadioButton radMale = new JRadioButton(" Male ");
    private JLabel lblDumy = new JLabel("");
    private JRadioButton radFemale = new JRadioButton(" Female ");
    private ButtonGroup genderChoice = new ButtonGroup();

    private JButton btnAdd = new JButton("Add service provider ");
    private JButton btnExit = new JButton("Exit");

    private DefaultTableModel tblModel;

    private JTable table;
    private String strOutput;
    private boolean empty;
    
   FileWriter fw;
   BufferedWriter bw;

    public MyJTable() {
        super("TABLE OF SERVICE");
        //layout of panels
        tblModel = new DefaultTableModel();
        table = new JTable(tblModel);

        pnlTop.setLayout(new GridLayout(5, 2));
        pnlCenter.setLayout(new GridLayout(4, 2));
        pnlBtm.setLayout(new GridLayout(1, 2));
        pnlTop.add(lblService);
        pnlTop.add(service);
        pnlTop.add(lblname);
        pnlTop.add(txtName);
        pnlTop.add(lblsurname);
        pnlTop.add(txtSurname);
        pnlTop.add(lblGender);
        pnlTop.add(radMale);
        genderChoice.add(radMale);
        genderChoice.add(radFemale);

        pnlTop.add(lblDumy);
        pnlTop.add(radFemale);

        tblModel.addColumn("Service");
        tblModel.addColumn("Name");
        tblModel.addColumn("Surname");
        tblModel.addColumn("Gender");
        tblModel.insertRow(0, new Object[]{"Plumber", "Junaid", "Maroga", "male"});
        tblModel.insertRow(1, new Object[]{"Gardner", "Phihlello", "Matuludi", "male"});
        tblModel.insertRow(2, new Object[]{"Baby Sitting", "Eva", "Buckley", "famale"});

        //pnlCenter.add(new JScrollPane (tblService));
        pnlCenter.add(new JScrollPane(table));
        pnlBtm.add(btnAdd);
        pnlBtm.add(btnExit);

        btnAdd.addActionListener(this);
        btnExit.addActionListener(this);

        //layout of the GUI
        this.setLayout(new BorderLayout());
        this.add(pnlTop, BorderLayout.NORTH);
        this.add(pnlCenter, BorderLayout.CENTER);
        this.add(pnlBtm, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAdd) {
            readValuesFromFields();
        }
        if (e.getSource() == btnExit) {

            System.exit(0);
        }

   }

    public void readValuesFromFields() {
        
        openFile();
        
        String radOutcome = ("No Selection");
        if (radMale.isSelected()) {
            radOutcome = ("Male");
            empty = false;
        } else if (radFemale.isSelected()) {
            radOutcome = ("Female");
            empty = false;
        }
        if (!empty) {
            tblModel.addRow(new Object[]{(String) service.getSelectedItem(), txtName.getText(), txtSurname.getText(), radOutcome});
            strOutput = (String) service.getSelectedItem() + "#" + txtName.getText() + "#" + txtSurname.getText() + "#" + radOutcome+ "\n";
            System.out.println(strOutput);
            
            processFile(strOutput);
            
            closeFile();
            
            clearFields();
            
            empty = true;
        } else {
            JOptionPane.showMessageDialog(null, "Please make the entries");
        }
            
    }
    public void clearFields() {
        service.setSelectedItem(-1);
        txtName.setText(null);
        txtSurname.setText(null);
        radMale.setSelected(false);
        radFemale.setSelected(false);
        genderChoice.clearSelection();
    }
    private void opneFile()throws IOException {
    
        fw = new FileWriter("myFile3.txt",true);
        bw = new BufferedWriter(fw);
        
    }
    private void openFile(){
        try{
            fw = new FileWriter("myFile3.txt",true);
            bw =new BufferedWriter(fw);
            System.out.println("File open for writing");
        }catch(IOException ie){
            String strError =ie.toString();
            JOptionPane.showMessageDialog(null,strError);
            System.out.println("My Error" + ie.toString());
        }
    }
    private void processFile (String strOutput){
        try{
            bw.write(strOutput);
        }catch(IOException ie){
            String strError = ie.toString();
            JOptionPane.showMessageDialog(null, strError);
            System.out.println("my Error " + ie.toString());
        }
    }
    public  void closeFile(){
        try{
            bw.close();
        }catch(IOException ie){
            String strError =ie.toString();
            JOptionPane.showMessageDialog(null, strError);
            System.out.println("my Error " + ie.toString());
        }
            
    }
}// End of class

