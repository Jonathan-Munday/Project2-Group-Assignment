/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.cput.runmyjtable;

import javax.swing.JFrame;

/**
 *
 * @author PHIHLE
 */
public class RunMyJTable {

    public static void main(String[] args) {
       MyJTable tbObjects = new MyJTable();
       tbObjects.pack();
       tbObjects.setSize(600,600);
       tbObjects.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       //tbObjects.add(scrollPane);
       tbObjects.setVisible(true);
    }
}
